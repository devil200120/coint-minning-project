import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Production server URL
  static const String baseUrl = 'http://72.62.167.180:5002/api';

  static String? _authToken;

  // Set auth token after login
  static void setAuthToken(String token) {
    _authToken = token;
  }

  // Clear auth token on logout
  static void clearAuthToken() {
    _authToken = null;
  }

  // Get headers with auth token
  static Map<String, String> get _headers {
    final headers = {'Content-Type': 'application/json'};
    if (_authToken != null) {
      headers['Authorization'] = 'Bearer $_authToken';
    }
    return headers;
  }

  // Google Sign In
  static Future<Map<String, dynamic>> googleSignIn({
    required String idToken,
    String? referralCode,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/google'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'idToken': idToken,
        if (referralCode != null && referralCode.isNotEmpty)
          'referralCode': referralCode,
      }),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      setAuthToken(data['token']);
      return data;
    } else {
      throw Exception(data['message'] ?? 'Google sign in failed');
    }
  }

  // Get current user profile
  static Future<Map<String, dynamic>> getCurrentUser() async {
    final response = await http.get(
      Uri.parse('$baseUrl/auth/me'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get user');
    }
  }

  // Get user profile
  static Future<Map<String, dynamic>> getProfile() async {
    final response = await http.get(
      Uri.parse('$baseUrl/users/profile'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get profile');
    }
  }

  // Get user dashboard
  static Future<Map<String, dynamic>> getDashboard() async {
    final response = await http.get(
      Uri.parse('$baseUrl/users/dashboard'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get dashboard');
    }
  }

  // Daily check-in
  static Future<Map<String, dynamic>> dailyCheckIn() async {
    final response = await http.post(
      Uri.parse('$baseUrl/users/daily-checkin'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Check-in failed');
    }
  }

  // Get mining status
  static Future<Map<String, dynamic>> getMiningStatus() async {
    final response = await http.get(
      Uri.parse('$baseUrl/mining/status'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get mining status');
    }
  }

  // Start mining
  static Future<Map<String, dynamic>> startMining() async {
    final response = await http.post(
      Uri.parse('$baseUrl/mining/start'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to start mining');
    }
  }

  // Claim mining rewards
  static Future<Map<String, dynamic>> claimMining() async {
    final response = await http.post(
      Uri.parse('$baseUrl/mining/claim'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to claim rewards');
    }
  }

  // Get wallet
  static Future<Map<String, dynamic>> getWallet() async {
    final response = await http.get(
      Uri.parse('$baseUrl/wallet'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get wallet');
    }
  }

  // Get referrals
  static Future<Map<String, dynamic>> getReferrals() async {
    final response = await http.get(
      Uri.parse('$baseUrl/referrals'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get referrals');
    }
  }

  // Get notifications
  static Future<Map<String, dynamic>> getNotifications({int page = 1}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/notifications?page=$page&limit=20'),
      headers: _headers,
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Failed to get notifications');
    }
  }

  // Validate referral code
  static Future<Map<String, dynamic>> validateReferralCode(String code) async {
    final response = await http.get(
      Uri.parse('$baseUrl/referrals/validate/$code'),
      headers: {'Content-Type': 'application/json'},
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success'] == true) {
      return data;
    } else {
      throw Exception(data['message'] ?? 'Invalid referral code');
    }
  }

  // Logout
  static Future<void> logout() async {
    try {
      await http.post(
        Uri.parse('$baseUrl/auth/logout'),
        headers: _headers,
      );
    } finally {
      clearAuthToken();
    }
  }
}
